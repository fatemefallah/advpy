class Vehicle:
    def __init__(self, name, price, number_of_seats, max_speed):
        self.name = name
        self.price = price
        self.number_of_seats = number_of_seats
        self.max_speed = max_speed


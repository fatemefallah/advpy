class Vehicle:
    def __init__(self, name, price, number_of_seats, max_speed):
        self.name = name
        self.price = price
        self.number_of_seats = number_of_seats
        self.max_speed = max_speed
        
'''    def outp(self):
        print(self.name, self.number_of_seats, self.price, self.max_speed)

v = Vehicle(name="Car", price=5000, number_of_seats=5, max_speed=280)
v.outp()'''